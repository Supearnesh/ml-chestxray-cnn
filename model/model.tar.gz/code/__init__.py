# train/__init__.py
from .model import CNNClassifier